var canvas = document.getElementById("myCanvas");
            var ctx = canvas.getContext("2d");
            var ballRadius = 10;
            var x = 10;//canvas.width/2;
            var y = 150;//canvas.height-30;
            var dx = (Math.floor(Math.random() * (10 - 7) + 7));
            var dy = 0;
            var score = 0;
            var scoreL, scoreR = 0;

            function drawBall() {
                ctx.beginPath();
                ctx.arc(x, y, ballRadius, 0, Math.PI*2);
                ctx.fillStyle = "#0095DD";
                ctx.fill();
                ctx.closePath();
            }

            function draw() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                drawBall();

                if(x + dx > canvas.width-ballRadius || x + dx < ballRadius) {
                    score += 1;
                    console.log(score);
                    dx = -dx;
                    console.log(dx);
                    
                    
                }

                x += dx;
                y += dy;
            }

            setInterval(draw, 1);

            function score() {
                //ф расчета счета и победы
            }